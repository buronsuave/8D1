package controles;

import java.util.ArrayList;
import model.Persona;

/**
 *
 * @author David
 */
public class Registro 
{
    public static final ArrayList<Persona> datos = new ArrayList<> ();
}
