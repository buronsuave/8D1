package captura8d;

import vistas.ConsultaYCaptura;

/**
 *
 * @author David
 */
public class Captura8D {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        new ConsultaYCaptura().setVisible(true);
    }
    
}
