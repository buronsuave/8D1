package Exceptions;

public class InvalidPhilNumber extends Exception
{
    public InvalidPhilNumber(String message)
    {
        super(message);
    }
}
